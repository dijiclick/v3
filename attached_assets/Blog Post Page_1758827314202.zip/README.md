
  # Blog Post Page

  This is a code bundle for Blog Post Page. The original project is available at https://www.figma.com/design/HbLoGx33Bn31fCyBGozXlA/Blog-Post-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  